const Ae='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#98A2B3" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18"/><path d="M3.6 9h16.8"/><path d="M3.6 15h16.8"/><path d="M11.5 3a17 17 0 0 0 0 18"/><path d="M12.5 3a17 17 0 0 1 0 18"/></svg>',Be=`data:image/svg+xml;utf8,${encodeURIComponent(Ae)}`;function ze(v){const w=new Set,m=d=>{const k=(d??"").trim();k&&w.add(k)};m(v.favIconUrl);try{if(v.url){const d=new URL(v.url);m(new URL("/favicon.ico",d.origin).toString()),m(`https://www.google.com/s2/favicons?sz=64&domain_url=${encodeURIComponent(d.origin)}`),m(`https://icons.duckduckgo.com/ip3/${d.hostname}.ico`)}}catch{}const I=(v.domain??"").trim();return I&&(m(`https://www.google.com/s2/favicons?sz=64&domain=${encodeURIComponent(I)}`),m(`https://icons.duckduckgo.com/ip3/${I}.ico`)),m(Be),Array.from(w)}function _e(v,w){const m=w+1;return m>=v.length?{nextSrc:void 0,nextIndex:w,exhausted:!0}:{nextSrc:v[m],nextIndex:m,exhausted:!1}}(()=>{const w="__musemark_content_ready__",m="musemark-quickdock-style",I=window;if(I[w])return;I[w]=!0;let d=null,k="",H="",M="",A=new Set,q=!1,l=null,B=!0,h="expanded",C="right",g=[],L=new Set,Y="default",z=0,j=!1,$,E,_=!1,O=null,b=null,N=null,X=0;const ie=32;chrome.runtime.onMessage.addListener((e,o,t)=>{if(!e||e.protocolVersion!==1)return!1;if(e.type==="musemark/startCapture"){const n=e.payload;return k=n.sessionId,M="",A=new Set,q=!1,ae("Captured. AI is analyzing..."),(async()=>{const i=await qe(n.sessionId,n.maxChars);t(i)})(),!0}if(e.type==="musemark/bookmarkLinked"){const n=e.payload;return n.sessionId===k&&(H=n.bookmarkId),!1}if(e.type==="musemark/stage1Ready"){const n=e.payload;return n.sessionId===k&&re(n.summary,n.suggestedCategoryCandidates,n.suggestedTags,n.textTruncated),!1}if(e.type==="musemark/classifyPending")return e.payload.sessionId===k&&d&&(q=!1,d.status.textContent="Classifying and saving..."),!1;if(e.type==="musemark/stageError"){const n=e.payload;return n.sessionId===k&&d&&(q=!1,d.status.textContent="Saved to Inbox with AI error",d.summary.textContent=n.error),!1}if(e.type==="musemark/finalized"){const n=e.payload;if(n.sessionId===k&&d){q=!1;const i=n.category||"Uncategorized",s=(n.tags??[]).join(", ");d.status.textContent=`Saved: ${i}${s?` | ${s}`:""}`,d.summary.textContent="Done. Auto closing...",window.setTimeout(()=>{Q(),f()},1200)}return!1}return!1}),document.addEventListener("keydown",e=>{if(e.key==="Escape"&&y(),e.key==="Escape"&&d?.root.style.display!=="none"){Q();return}if((e.metaKey||e.ctrlKey)&&e.shiftKey&&e.key.toLowerCase()==="k"){e.preventDefault(),pe();return}if(!e.ctrlKey||e.metaKey||e.altKey||e.shiftKey||we(e.target))return;const o=xe(e);if(o===void 0)return;const t=g[o];t&&(e.preventDefault(),z=o,U(),Z(t))}),document.addEventListener("click",()=>{y()}),window.addEventListener("focus",()=>{f()}),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&f()}),le();function V(){if(d)return d;const e=document.createElement("div");e.id="musemark-overlay",e.innerHTML=`
      <div class="musemark-card">
        <div class="musemark-title">MuseMark</div>
        <div class="musemark-status"></div>
        <div class="musemark-summary"></div>
        <div class="musemark-section">
          <div class="musemark-label">Category candidates</div>
          <div class="musemark-category-box"></div>
        </div>
        <div class="musemark-section">
          <div class="musemark-label">Tag candidates</div>
          <div class="musemark-tag-box"></div>
        </div>
        <input class="musemark-input" type="text" maxlength="200" placeholder="One-line note (optional). Press Enter to save..." />
        <div class="musemark-hint">Enter = save now, Esc = close (keeps bookmark in Inbox)</div>
        <div class="musemark-actions">
          <button class="musemark-manager">Open Library</button>
        </div>
      </div>
    `;const o=document.createElement("style");o.textContent=`
      #musemark-overlay {
        position: fixed;
        right: 18px;
        bottom: 18px;
        z-index: 2147483647;
        width: min(430px, calc(100vw - 28px));
        font-family: "Avenir Next", "SF Pro Display", "Noto Sans SC", sans-serif;
      }
      #musemark-overlay .musemark-card {
        border-radius: 16px;
        background: linear-gradient(135deg, #101a34 0%, #1d2746 48%, #1f385f 100%);
        color: #f4f8ff;
        border: 1px solid rgba(214, 224, 255, 0.28);
        box-shadow: 0 22px 52px rgba(5, 10, 25, 0.42);
        padding: 14px 14px 12px;
        backdrop-filter: blur(8px);
        animation: musemark-enter 170ms ease-out;
      }
      #musemark-overlay .musemark-title {
        font-weight: 750;
        letter-spacing: 0.2px;
        font-size: 15px;
        margin-bottom: 8px;
      }
      #musemark-overlay .musemark-status {
        font-size: 13px;
        color: #d3e2ff;
      }
      #musemark-overlay .musemark-summary {
        margin-top: 8px;
        font-size: 12px;
        line-height: 1.45;
        color: #d8e6ff;
        max-height: 88px;
        overflow: auto;
        white-space: pre-wrap;
      }
      #musemark-overlay .musemark-section {
        margin-top: 10px;
      }
      #musemark-overlay .musemark-label {
        font-size: 11px;
        color: #a8c5ff;
        margin-bottom: 6px;
      }
      #musemark-overlay .musemark-category-box,
      #musemark-overlay .musemark-tag-box {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }
      #musemark-overlay .musemark-chip {
        border: 1px solid rgba(190, 212, 255, 0.4);
        background: rgba(23, 46, 79, 0.72);
        color: #eff6ff;
        border-radius: 999px;
        font-size: 11px;
        padding: 4px 9px;
        cursor: pointer;
      }
      #musemark-overlay .musemark-chip.active {
        background: #8bd1ff;
        border-color: #8bd1ff;
        color: #07203a;
      }
      #musemark-overlay .musemark-input {
        width: 100%;
        margin-top: 12px;
        border-radius: 10px;
        border: 1px solid rgba(187, 208, 255, 0.5);
        background: rgba(9, 20, 38, 0.65);
        color: #f3f8ff;
        padding: 9px 10px;
        font-size: 13px;
        outline: none;
      }
      #musemark-overlay .musemark-input:focus {
        border-color: #9bc8ff;
        box-shadow: 0 0 0 2px rgba(123, 188, 255, 0.26);
      }
      #musemark-overlay .musemark-hint {
        margin-top: 8px;
        font-size: 11px;
        color: #b8d1ff;
      }
      #musemark-overlay .musemark-actions {
        margin-top: 10px;
        display: flex;
        justify-content: flex-end;
      }
      #musemark-overlay .musemark-manager {
        border: none;
        border-radius: 10px;
        background: #86d4ff;
        color: #072039;
        font-weight: 650;
        padding: 7px 10px;
        cursor: pointer;
        font-size: 12px;
      }
      @keyframes musemark-enter {
        from {
          transform: translateY(8px);
          opacity: 0;
        }
        to {
          transform: translateY(0);
          opacity: 1;
        }
      }
    `;const t=e.querySelector(".musemark-status"),n=e.querySelector(".musemark-summary"),i=e.querySelector(".musemark-input"),s=e.querySelector(".musemark-category-box"),c=e.querySelector(".musemark-tag-box"),r=e.querySelector(".musemark-hint"),a=e.querySelector(".musemark-manager");let u=!1;return i.addEventListener("compositionstart",()=>{u=!0}),i.addEventListener("compositionend",()=>{u=!1}),i.addEventListener("keydown",p=>{const D=u||p.isComposing||p.keyCode===229;p.key==="Enter"&&!p.shiftKey&&!D&&(p.preventDefault(),ce())}),a.addEventListener("click",()=>{x("content/openManager",{})}),e.style.display="none",document.documentElement.appendChild(o),document.documentElement.appendChild(e),d={root:e,status:t,summary:n,noteInput:i,categoryBox:s,tagBox:c,saveHint:r},d}function ae(e){const o=V();o.root.style.display="block",o.status.textContent=e,o.summary.textContent="",o.noteInput.value="",o.saveHint.textContent="Enter = save now, Esc = close (keeps bookmark in Inbox)",o.categoryBox.innerHTML="",o.tagBox.innerHTML="",o.noteInput.focus(),ee(!0)}function Q(){d&&(d.root.style.display="none",ee(!1))}function re(e,o,t,n){const i=V();i.status.textContent="AI analyzed page. Add a note and press Enter.",i.summary.textContent=n?`${e}

Text was truncated due to max character limit.`:e,i.noteInput.focus(),se(o),de(t)}function se(e){if(d){d.categoryBox.innerHTML="";for(const o of e.slice(0,6)){const t=te(o);if(!t)continue;const n=document.createElement("button");n.type="button",n.className="musemark-chip",n.textContent=t,n.addEventListener("click",()=>{M=M===t?"":t,(d?.categoryBox.querySelectorAll(".musemark-chip")??[]).forEach(s=>s.classList.remove("active")),M===t&&n.classList.add("active")}),d.categoryBox.appendChild(n)}}}function de(e){if(d){d.tagBox.innerHTML="";for(const o of e.slice(0,12)){const t=te(o);if(!t)continue;const n=document.createElement("button");n.type="button",n.className="musemark-chip",n.textContent=t,n.addEventListener("click",()=>{A.has(t)?(A.delete(t),n.classList.remove("active")):(A.add(t),n.classList.add("active"))}),d.tagBox.appendChild(n)}}}async function ce(){if(!(!d||q||!k)){q=!0,d.status.textContent="Saving...";try{await x("content/submitNote",{sessionId:k,bookmarkId:H||void 0,note:d.noteInput.value,selectedCategory:M||void 0,selectedTags:Array.from(A)})}catch(e){q=!1,d.status.textContent="Save failed",d.summary.textContent=ne(e)}}}async function le(){await f(),$!==void 0&&clearInterval($),$=window.setInterval(()=>{f()},45e3)}async function f(){let e;try{e=await x("quickDock/getState",{currentUrl:location.href})}catch(t){const n=ne(t).toLowerCase();(n.includes("unknown message type")||n.includes("quickdock"))&&(B=!1,l&&(l.root.style.display="none"));return}if(B=!!e.enabled,g=Array.isArray(e.entries)?e.entries:[],L=new Set(Array.isArray(e.pinnedIds)?e.pinnedIds:[]),Y=e.layout?.activeProfileId||"default",h=ye(e.layout?.mode)||h,C=ve(e.position)||C,!B){l&&(l.root.style.display="none");return}z>=g.length&&(z=0);const o=R();o.root.style.display=j?"none":"block",P()}function R(){if(l)return l;ue();const e=document.createElement("div");e.id="musemark-quickdock",e.dataset.position=C,e.classList.add(C==="bottom_center"?"pos-bottom":"pos-right"),e.innerHTML=`
      <div class="anqd-controls">
        <button class="anqd-restore" type="button" title="Show Dock (Cmd/Ctrl+Shift+K)" aria-label="Show Dock"></button>
        <button class="anqd-hide" type="button" title="Hide Dock" aria-label="Hide Dock"></button>
      </div>
      <div class="anqd-rail">
        <div class="anqd-list" role="list"></div>
      </div>
    `;const o=e.querySelector(".anqd-rail"),t=e.querySelector(".anqd-list"),n=e.querySelector(".anqd-hide"),i=e.querySelector(".anqd-restore");return n.addEventListener("click",()=>{F("collapsed")}),i.addEventListener("click",()=>{F("expanded")}),document.documentElement.appendChild(e),l={root:e,rail:o,list:t,hideButton:n,restoreButton:i},l}function ue(){const e=document.getElementById(m),o=e??document.createElement("style");o.id=m,o.textContent=`
      #musemark-quickdock {
        position: fixed;
        right: 0;
        top: 50%;
        transform: translateY(-50%);
        z-index: 2147483645;
        font-family: "Avenir Next", "SF Pro Text", "Noto Sans SC", sans-serif;
        opacity: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 18px;
        width: 46px;
      }
      #musemark-quickdock .anqd-controls {
        width: 46px;
        min-height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      #musemark-quickdock.pos-bottom {
        right: auto;
        top: auto;
        left: 50%;
        bottom: 16px;
        transform: translateX(-50%);
        width: auto;
        max-width: min(92vw, 920px);
        flex-direction: row;
        align-items: center;
        gap: 12px;
      }
      #musemark-quickdock.pos-bottom .anqd-controls {
        width: auto;
        min-height: 0;
        flex: 0 0 auto;
      }
      #musemark-quickdock .anqd-restore {
        position: relative;
        width: 36px;
        height: 22px;
        border: none;
        outline: none;
        border-radius: 9px;
        background: transparent;
        color: transparent;
        display: none;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: transform 180ms ease, filter 180ms ease;
        box-shadow: none;
      }
      #musemark-quickdock .anqd-hide {
        position: relative;
        width: 36px;
        height: 22px;
        border: none;
        outline: none;
        border-radius: 9px;
        background: transparent;
        color: transparent;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        z-index: 2;
        transition: transform 180ms ease, filter 180ms ease;
        box-shadow: none;
      }
      #musemark-quickdock .anqd-hide::before,
      #musemark-quickdock .anqd-restore::before {
        content: "";
        position: absolute;
        left: 7px;
        right: 7px;
        top: 50%;
        height: 1.5px;
        transform: translateY(-50%);
        background: linear-gradient(
          90deg,
          transparent 0%,
          rgba(118, 118, 118, 0.92) 18%,
          rgba(156, 156, 156, 0.98) 50%,
          rgba(118, 118, 118, 0.92) 82%,
          transparent 100%
        );
        box-shadow:
          0 0 8px rgba(84, 84, 84, 0.46),
          0 0 14px rgba(60, 60, 60, 0.28);
        transition: transform 180ms ease, opacity 180ms ease;
      }
      #musemark-quickdock .anqd-hide::after,
      #musemark-quickdock .anqd-restore::after {
        content: "";
        position: absolute;
        left: 50%;
        width: 7px;
        height: 7px;
        border-right: 1.5px solid rgba(124, 124, 124, 0.96);
        border-bottom: 1.5px solid rgba(124, 124, 124, 0.96);
        transform-origin: center;
        filter: drop-shadow(0 0 5px rgba(72, 72, 72, 0.38));
      }
      #musemark-quickdock .anqd-hide::after {
        top: 1px;
        transform: translateX(-50%) rotate(45deg);
      }
      #musemark-quickdock .anqd-restore::after {
        top: 6px;
        transform: translateX(-50%) rotate(-135deg);
      }
      #musemark-quickdock .anqd-hide:hover::before,
      #musemark-quickdock .anqd-restore:hover::before {
        transform: translateY(-50%) scaleX(0.74);
        opacity: 0.95;
      }
      #musemark-quickdock .anqd-hide:hover,
      #musemark-quickdock .anqd-restore:hover {
        transform: translateY(-1px);
        filter: drop-shadow(0 0 10px rgba(92, 92, 92, 0.38));
      }
      #musemark-quickdock.is-transitioning .anqd-hide,
      #musemark-quickdock.is-transitioning .anqd-restore {
        pointer-events: none;
      }
      #musemark-quickdock .anqd-rail {
        position: relative;
        width: 46px;
        border: none;
        outline: none;
        border-radius: 0;
        background: transparent;
        box-shadow: none;
        backdrop-filter: none;
        -webkit-backdrop-filter: none;
        padding: 0;
        display: flex;
        align-items: stretch;
        justify-content: center;
        z-index: 1;
        overflow: visible;
        transition: opacity 140ms ease, transform 140ms ease;
      }
      #musemark-quickdock.pos-bottom .anqd-rail {
        width: auto;
        max-width: min(92vw, 860px);
        overflow: hidden;
      }
      #musemark-quickdock.pos-right.is-collapsed .anqd-rail {
        opacity: 0;
        transform: translateX(16px) scale(0.96);
        pointer-events: none;
      }
      #musemark-quickdock.pos-bottom.is-collapsed .anqd-rail {
        opacity: 0;
        transform: translateY(12px) scale(0.96);
        pointer-events: none;
        max-width: 0;
      }
      #musemark-quickdock.pos-right.is-collapsed .anqd-restore,
      #musemark-quickdock.pos-bottom.is-collapsed .anqd-restore {
        display: inline-flex;
      }
      #musemark-quickdock.pos-right.is-collapsed .anqd-hide,
      #musemark-quickdock.pos-bottom.is-collapsed .anqd-hide {
        display: none;
      }
      #musemark-quickdock .anqd-list {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 24px;
        max-height: min(72vh, 760px);
        overflow-y: auto;
        width: 100%;
        padding: 0;
      }
      #musemark-quickdock.pos-bottom .anqd-list {
        flex-direction: row;
        align-items: center;
        gap: 24px;
        width: auto;
        max-width: min(92vw, 820px);
        max-height: none;
        overflow-x: auto;
        overflow-y: hidden;
        padding: 2px 2px;
      }
      #musemark-quickdock .anqd-list::-webkit-scrollbar {
        width: 0;
        height: 0;
      }
      #musemark-quickdock .anqd-item {
        position: relative;
        width: 30px;
        height: 30px;
        border: none;
        outline: none;
        border-radius: 10px;
        background: transparent;
        box-shadow: none;
        cursor: pointer;
        padding: 0;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        opacity: 1;
        transform: translateY(0) scale(1);
        transition:
          opacity 72ms ease-in-out,
          transform 72ms ease-in-out,
          box-shadow 140ms ease;
        transition-delay:
          calc(var(--idx, 0) * 32ms),
          calc(var(--idx, 0) * 32ms),
          0ms;
      }
      #musemark-quickdock.pos-right.is-opening .anqd-item,
      #musemark-quickdock.pos-right.is-closing .anqd-item {
        opacity: 0;
        transform: translateY(-8px) scale(0.96);
      }
      #musemark-quickdock.pos-bottom.is-opening .anqd-item,
      #musemark-quickdock.pos-bottom.is-closing .anqd-item {
        opacity: 0;
        transform: translateY(8px) scale(0.96);
      }
      #musemark-quickdock .anqd-item.selected {
        box-shadow: 0 0 22px rgba(255, 255, 255, 0.2);
      }
      #musemark-quickdock .anqd-item[data-pinned="true"] {
        cursor: grab;
      }
      #musemark-quickdock .anqd-item[data-pinned="true"]:active {
        cursor: grabbing;
      }
      #musemark-quickdock .anqd-item.is-dragging {
        opacity: 0.58;
        transform: scale(0.96);
      }
      #musemark-quickdock .anqd-item.is-drop-target {
        box-shadow:
          inset 0 0 0 1px rgba(182, 223, 255, 0.78),
          0 0 0 1px rgba(143, 202, 255, 0.44);
      }
      #musemark-quickdock .anqd-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: inherit;
        opacity: 1;
      }
      #musemark-quickdock .anqd-fallback {
        width: 100%;
        height: 100%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: inherit;
        font-size: 13px;
        font-weight: 600;
        color: rgba(170, 178, 193, 0.94);
        background: rgba(32, 37, 47, 0.78);
        box-shadow: inset 0 0 0 0.8px rgba(195, 203, 220, 0.16);
        opacity: 1;
      }
      #musemark-quickdock .anqd-slot {
        position: absolute;
        right: -8px;
        top: -8px;
        min-width: 24px;
        height: 24px;
        padding: 0 4px;
        border-radius: 999px;
        border: none;
        background: transparent;
        color: rgba(248, 250, 255, 0.92);
        font-size: 20px;
        line-height: 24px;
        text-align: center;
        opacity: 0;
        transition: none;
      }
      #musemark-quickdock .anqd-item.selected .anqd-slot {
        opacity: 1;
      }
      #musemark-quickdock .anqd-pinned {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        bottom: 0;
        width: 8px;
        height: 8px;
        border-radius: 999px;
        background: transparent;
        box-shadow:
          inset 0 0 0 1.2px rgba(255, 255, 255, 0.95),
          0 0 8px rgba(189, 231, 255, 0.36);
      }
      #musemark-quickdock .anqd-empty {
        width: 30px;
        min-height: 80px;
        border-radius: 10px;
        border: none;
        background: transparent;
        color: rgba(247, 249, 255, 0.8);
        font-size: 20px;
        line-height: 1.1;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        padding: 12px;
      }
      #musemark-quickdock .anqd-menu {
        position: fixed;
        z-index: 2147483646;
        min-width: 190px;
        border-radius: 10px;
        border: 1px solid rgba(170, 177, 191, 0.78);
        background: rgba(245, 247, 251, 0.98);
        box-shadow: 0 16px 36px rgba(14, 19, 30, 0.24);
        padding: 6px;
        display: none;
      }
      #musemark-quickdock .anqd-menu button {
        width: 100%;
        text-align: left;
        border: none;
        border-radius: 7px;
        background: transparent;
        color: #2f3a4f;
        font-size: 12px;
        padding: 7px;
        cursor: pointer;
      }
      #musemark-quickdock .anqd-menu button:hover {
        background: rgba(219, 225, 236, 0.88);
      }
      @media (max-width: 960px) {
        #musemark-quickdock.pos-right {
          right: 0;
        }
        #musemark-quickdock.pos-bottom {
          bottom: 12px;
          max-width: 94vw;
          gap: 10px;
        }
        #musemark-quickdock .anqd-hide,
        #musemark-quickdock .anqd-restore {
          width: 34px;
          height: 20px;
          border-radius: 8px;
        }
        #musemark-quickdock .anqd-hide::before,
        #musemark-quickdock .anqd-restore::before {
          left: 6px;
          right: 6px;
        }
        #musemark-quickdock .anqd-rail {
          width: 42px;
          border-radius: 0;
          padding: 0;
        }
        #musemark-quickdock.pos-bottom .anqd-rail {
          width: auto;
          max-width: calc(94vw - 46px);
        }
        #musemark-quickdock.pos-bottom .anqd-list {
          max-width: calc(94vw - 46px);
          gap: 18px;
        }
        #musemark-quickdock .anqd-item {
          width: 27px;
          height: 27px;
          border-radius: 9px;
        }
      }
    `,e||document.documentElement.appendChild(o)}function P(){if(!l)return;l.root.dataset.position=C,l.root.classList.toggle("pos-right",C==="right"),l.root.classList.toggle("pos-bottom",C==="bottom_center"),l.root.classList.contains("is-opening")||l.root.classList.contains("is-closing")||l.root.classList.toggle("is-collapsed",h==="collapsed"),U()}function U(){if(!l)return;const e=l.list;e.innerHTML="";const o=g.slice(0,10);if(o.length===0){const t=document.createElement("div");t.className="anqd-empty",t.textContent="No bookmarks",e.appendChild(t);return}o.forEach((t,n)=>{const i=document.createElement("button");i.type="button",i.className="anqd-item",i.dataset.entryId=t.id,i.style.setProperty("--idx",String(n)),n===z&&i.classList.add("selected");const s=ge(n);i.title=`${t.title}
Shortcut: Ctrl+${s}`;const c=W(t);if(i.dataset.pinned=c?"true":"false",t.kind==="bookmark"){const a=ze({favIconUrl:t.favIconUrl,url:t.url,domain:t.domain}),u=document.createElement("img");u.alt=t.domain||t.title,u.referrerPolicy="no-referrer";let p=0,D=!1;u.src=a[p]??"",u.addEventListener("error",()=>{if(D)return;const T=_e(a,p);if(T.exhausted||!T.nextSrc){D=!0,u.remove();const S=document.createElement("div");S.className="anqd-fallback",S.textContent=(t.domain||t.title||"?").slice(0,1).toUpperCase(),i.appendChild(S);return}p=T.nextIndex,u.src=T.nextSrc}),i.appendChild(u)}else{const a=document.createElement("div");a.className="anqd-fallback",a.textContent=(t.domain||t.title||"?").slice(0,1).toUpperCase(),i.appendChild(a)}const r=document.createElement("span");if(r.className="anqd-slot",r.textContent=s,i.appendChild(r),c){const a=document.createElement("span");a.className="anqd-pinned",a.title="Pinned",i.appendChild(a)}t.kind==="bookmark"&&i.addEventListener("contextmenu",a=>{if(b){a.preventDefault();return}a.preventDefault(),he(t,a.clientX,a.clientY)}),c&&(i.draggable=!0,i.addEventListener("dragstart",a=>{b=t.id,N=null,y(),G(),i.classList.add("is-dragging"),a.dataTransfer&&(a.dataTransfer.effectAllowed="move",a.dataTransfer.setData("text/plain",t.id))}),i.addEventListener("dragover",a=>{!b||b===t.id||(a.preventDefault(),a.dataTransfer&&(a.dataTransfer.dropEffect="move"),N!==t.id&&(N=t.id,G(),i.classList.add("is-drop-target")))}),i.addEventListener("drop",a=>{if(!b||b===t.id)return;a.preventDefault();const u=b;X=Date.now()+350,me(u,t.id)}),i.addEventListener("dragend",()=>{K()})),i.addEventListener("click",()=>{Date.now()<X||(z=n,U(),Z(t))}),e.appendChild(i)})}function W(e){return e.kind==="bookmark"&&(L.has(e.id)||!!e.pinned)}function G(){l&&l.list.querySelectorAll(".anqd-item.is-drop-target").forEach(e=>{e.classList.remove("is-drop-target")})}function K(){if(!l){b=null,N=null;return}l.list.querySelectorAll(".anqd-item.is-dragging, .anqd-item.is-drop-target").forEach(e=>{e.classList.remove("is-dragging","is-drop-target")}),b=null,N=null}function J(e){const o=new Set(e),t=g.filter(r=>r.kind==="bookmark"&&(o.has(r.id)||L.has(r.id)||!!r.pinned)),n=new Map(t.map(r=>[r.id,r])),i=[],s=new Set;for(const r of e){const a=n.get(r);!a||s.has(r)||(s.add(r),i.push(a))}for(const r of t)s.has(r.id)||(s.add(r.id),i.push(r));let c=0;return g.map(r=>{if(r.kind==="bookmark"&&(o.has(r.id)||L.has(r.id)||r.pinned)){const a=i[c];return c+=1,a??r}return r})}async function me(e,o){const t=g.filter(W).map(r=>r.id),n=t.indexOf(e),i=t.indexOf(o);if(n<0||i<0||n===i){K();return}const s=[...t],[c]=s.splice(n,1);s.splice(i,0,c),L=new Set(s),g=J(s),K(),U();try{const r=await x("quickDock/reorderPinned",{orderedIds:s,profileId:Y});Array.isArray(r.pinnedIds)&&r.pinnedIds.length>0&&(L=new Set(r.pinnedIds),g=J(r.pinnedIds),U()),await f()}catch{await f()}}async function F(e,o){if(y(),_)return;const n=R().root,i=h,s=Math.max(1,Math.min(g.length,10)),c=Math.min(360,Math.max(220,(s-1)*ie+72));E!==void 0&&(window.clearTimeout(E),E=void 0),i==="collapsed"&&e==="expanded"?(_=!0,h="expanded",n.classList.remove("is-collapsed","is-closing"),n.classList.add("is-transitioning","is-opening"),P(),window.requestAnimationFrame(()=>{window.requestAnimationFrame(()=>{n.classList.remove("is-opening"),E=window.setTimeout(()=>{n.classList.remove("is-transitioning"),_=!1,E=void 0},c)})})):i==="expanded"&&e==="collapsed"?(_=!0,h="expanded",n.classList.remove("is-opening","is-collapsed","is-closing"),n.classList.add("is-transitioning"),P(),window.requestAnimationFrame(()=>{window.requestAnimationFrame(()=>{n.classList.add("is-closing"),E=window.setTimeout(()=>{h="collapsed",n.classList.remove("is-closing","is-transitioning"),P(),_=!1,E=void 0},c)})})):(h=e,n.classList.remove("is-opening","is-closing","is-transitioning"),P());try{await x("quickDock/updateLayout",{mode:e})}catch{return}}async function pe(){B&&await F(h==="collapsed"?"expanded":"collapsed")}async function Z(e){try{await x("quickDock/open",{id:e.kind==="bookmark"?e.id:void 0,url:e.url,action:e.kind==="action"?e.action:void 0,source:"dock"}),y(),window.setTimeout(()=>{f()},120)}catch{return}}async function ke(){try{await x("quickDock/open",{action:"open_library",source:"dock"})}catch{return}}async function fe(){try{await x("quickDock/saveCurrent",{}),window.setTimeout(()=>{f()},250)}catch{return}}function ge(e){return e===9?"0":String(e+1)}function xe(e){const o=e.code;if(o==="Digit0"||o==="Numpad0")return 9;const t=o.match(/^(Digit|Numpad)([1-9])$/);if(t?.[2])return Number(t[2])-1}function he(e,o,t){if(e.kind!=="bookmark")return;const n=be(),i=L.has(e.id)||!!e.pinned;n.innerHTML="";const s=document.createElement("button");s.type="button",s.textContent=i?"Unpin from Dock":"Pin to Dock",s.addEventListener("click",()=>{(async()=>{try{await x(i?"quickDock/unpin":"quickDock/pin",{bookmarkId:e.id}),y(),await f()}catch{return}})()});const c=document.createElement("button");c.type="button",c.textContent="Remove from suggestions",c.addEventListener("click",()=>{(async()=>{try{await x("quickDock/dismiss",{bookmarkId:e.id,days:30}),y(),await f()}catch{return}})()});const r=document.createElement("button");r.type="button",r.textContent="Open in Library",r.addEventListener("click",()=>{ke(),y()});const a=document.createElement("button");a.type="button",a.textContent="Save Current Page",a.addEventListener("click",()=>{fe(),y()}),n.appendChild(s),n.appendChild(c),n.appendChild(a),n.appendChild(r),n.style.left=`${Math.max(8,Math.min(o,window.innerWidth-210))}px`,n.style.top=`${Math.max(8,Math.min(t,window.innerHeight-140))}px`,n.style.display="block"}function be(){if(O)return O;const e=R(),o=document.createElement("div");return o.className="anqd-menu",e.root.appendChild(o),O=o,o}function y(){O&&(O.style.display="none")}function ee(e){j=e,l&&(l.root.style.display=e?"none":B?"block":"none")}async function x(e,o){const t=await chrome.runtime.sendMessage({protocolVersion:1,type:e,payload:o});if(!t?.ok)throw new Error(t?.error||`Runtime message failed: ${e}`);return t.data}function ye(e){if(e==="collapsed")return"collapsed";if(e==="expanded"||e==="peek")return"expanded"}function ve(e){if(e==="bottom_center")return"bottom_center";if(e==="right")return"right"}function we(e){if(!(e instanceof HTMLElement))return!1;const o=e.tagName.toLowerCase();return o==="input"||o==="textarea"||o==="select"?!0:!!e.closest("[contenteditable='true']")}async function qe(e,o){const t=document.title||location.hostname,i=document.querySelector("link[rel='canonical']")?.href||void 0,s=Ce(),c=window.getSelection()?.toString().trim()??"",a=document.querySelector("article, main")?.textContent?.trim()??"",u=document.body?.innerText?.trim()??"",p=a||u,D=c&&!p?"selection_only":a?"readability":"dom_text",T=c?`${c}

${p}`:p,S=De(T),Te=S.length>o,oe=S.slice(0,o),Me=await Se(oe||`${location.href}|${t}`);return{sessionId:e,url:location.href,canonicalUrl:i,title:t,domain:location.hostname,favIconUrl:s,selection:c,text:oe,textDigest:Me,textChars:S.length,captureMode:D,wasTruncated:Te}}function Ce(){const e=Array.from(document.querySelectorAll("link[rel*='icon'], link[rel='apple-touch-icon']"));let o="",t=-1;for(const n of e){const i=Ee(n.getAttribute("href"));if(!i||i.startsWith("data:"))continue;const s=(n.rel||"").toLowerCase(),c=(n.type||"").toLowerCase();let a=Le(n.sizes?.value);s.includes("icon")&&(a+=40),s.includes("shortcut")&&(a+=12),s.includes("apple-touch-icon")&&(a+=20),c.includes("svg")&&(a+=18),i.includes("favicon")&&(a+=8),a>t&&(t=a,o=i)}if(o)return o;try{return new URL("/favicon.ico",location.origin).toString()}catch{return}}function Le(e){const o=(e??"").trim().toLowerCase();if(!o||o==="any")return 24;let t=0;for(const n of o.split(/\s+/)){const i=n.match(/^(\d+)x(\d+)$/);if(!i)continue;const s=Number(i[1]),c=Number(i[2]);!Number.isFinite(s)||!Number.isFinite(c)||(t=Math.max(t,Math.min(s,c)))}return t<=0?8:Math.min(96,t)}function Ee(e){const o=(e??"").trim();if(!o)return"";try{return new URL(o,location.href).toString()}catch{return""}}async function Se(e){try{const o=new TextEncoder().encode(e),t=await crypto.subtle.digest("SHA-256",o);return Array.from(new Uint8Array(t)).map(i=>i.toString(16).padStart(2,"0")).join("")}catch{return Ie(e)}}function Ie(e){let o=0;for(let t=0;t<e.length;t+=1)o=(o<<5)-o+e.charCodeAt(t),o|=0;return`fallback_${Math.abs(o)}`}function De(e){return e.replace(/\r/g,`
`).replace(/[ \t]+/g," ").replace(/\n{3,}/g,`

`).trim()}function te(e){return e.trim().replace(/\s+/g," ").slice(0,40)}function ne(e){return e instanceof Error?e.message:String(e??"Unknown error")}})();
//# sourceMappingURL=content.js.map
